# KissDDoS 🌹💀
Hola!, te presento "Kiss DDoS" hace referencia a un beso y luego la muerte (Una rosa y la calavera)
---------------------------------------------------------------------------------------------------
![KissDDoS](https://cdn.discordapp.com/attachments/734839716914135219/828659631294382121/unknown.png)
---------------------------------------------------------------------------------------------------
**Instalacion:**

```
⚙️➜ Windows:

Descargar el archivo o git clone https://github.com/hashesterminal/KissDDoS.git
[win+r = cmd]
cd [Directorio del kissddos]
py kissddos.py

```

```
⚙️➜ Linux:

git clone https://github.com/hashesterminal/KissDDoS.git
cd [Directorio del kissddos]
python3 kissddos.py

```

* No es necesario que instales manualmente, la propia tool lo hara todo!
* Usar con responsabilidad o para pentesting.
  

# Libre uso ♟
La tool es completamente de libre uso, si quieres copiarla, estas en todo tu derecho, ¿La quieres poner a tu nombre?, Estas en todo tu derecho.

# Sin cargos 🌌
No me hago absolutamente cargo de nada de lo que hagas con esta tool, eres tu el responsable.
